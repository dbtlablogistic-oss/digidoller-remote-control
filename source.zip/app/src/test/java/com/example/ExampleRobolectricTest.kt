package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ServerConfigStore
import com.example.qr.QrCodeHelper
import com.example.webrtc.RemoteAssistEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Digidoller Remote Control`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Digidoller Remote Control", appName)
    }

    @Test
    fun `one time code and qr payload round trip`() {
        val code = ServerConfigStore.generateOneTimeCode()
        assertEquals(9, code.length)
        assertTrue(code[4] == '-')

        val payload = QrCodeHelper.buildPairingPayload(code, "wss://drc.example.com:8443")
        val parsed = QrCodeHelper.parsePairingPayload(payload)
        assertNotNull(parsed)
        assertEquals(code, parsed?.code)
        assertEquals("wss://drc.example.com:8443", parsed?.serverUrl)
    }

    @Test
    fun `remote assist event serializes cleanly`() {
        val event = RemoteAssistEvent(type = "POINTER", xNorm = 0.42f, yNorm = 0.78f, label = "Mobile A")
        val restored = RemoteAssistEvent.fromJsonString(event.toJsonString())
        assertNotNull(restored)
        assertEquals("POINTER", restored?.type)
        assertEquals(0.42f, restored?.xNorm ?: 0f, 0.001f)
        assertEquals(0.78f, restored?.yNorm ?: 0f, 0.001f)
    }
}

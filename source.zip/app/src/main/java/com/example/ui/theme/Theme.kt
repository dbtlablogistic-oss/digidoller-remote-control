package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DrcDarkColorScheme = darkColorScheme(
    primary = CyberBluePrimary,
    onPrimary = CyberBlack,
    primaryContainer = CyberBlueDeep,
    onPrimaryContainer = CyberTextPrimary,
    secondary = CyberBlueCobalt,
    onSecondary = CyberTextPrimary,
    secondaryContainer = CyberSurfaceHighlight,
    onSecondaryContainer = CyberBluePrimary,
    tertiary = CyberGreenActive,
    onTertiary = CyberBlack,
    background = CyberBlack,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorderGlow,
    error = CyberRedDanger,
    onError = CyberTextPrimary
)

val DrcShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun DigidollerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DrcDarkColorScheme,
        typography = DrcTypography,
        shapes = DrcShapes,
        content = content
    )
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Cyber Blue Palette
val CyberBlack = Color(0xFF050811)
val CyberSurface = Color(0xFF0A1120)
val CyberSurfaceElevated = Color(0xFF0F1A30)
val CyberSurfaceHighlight = Color(0xFF152442)

val CyberBluePrimary = Color(0xFF00E5FF)
val CyberBlueCobalt = Color(0xFF2979FF)
val CyberBlueDeep = Color(0xFF0D47A1)
val CyberBlueMuted = Color(0xFF5C85B8)

val CyberTextPrimary = Color(0xFFEAF4FF)
val CyberTextSecondary = Color(0xFF94ADC9)
val CyberBorderGlow = Color(0xFF1F3C6E)

val CyberGreenActive = Color(0xFF00E676)
val CyberAmberWarn = Color(0xFFFFAB00)
val CyberRedDanger = Color(0xFFFF3D57)

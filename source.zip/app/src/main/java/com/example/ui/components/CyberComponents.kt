package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBlueCobalt
import com.example.ui.theme.CyberBluePrimary
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberMonoFamily
import com.example.ui.theme.CyberRedDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun CyberGridBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        CyberBlack,
                        Color(0xFF070F20),
                        CyberBlack
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 36.dp.toPx()
            val lineColor = Color(0xFF0F2242).copy(alpha = 0.45f)
            var x = 0f
            while (x < size.width) {
                drawLine(
                    color = lineColor,
                    start = Offset(x, 0f),
                    end = Offset(x, size.height),
                    strokeWidth = 1f
                )
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(
                    color = lineColor,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
                y += step
            }
        }
        content()
    }
}

@Composable
fun CyberHudCard(
    modifier: Modifier = Modifier,
    borderColor: Color = CyberBorderGlow,
    containerColor: Color = CyberSurface.copy(alpha = 0.92f),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val baseModifier = modifier
        .clip(shape)
        .then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        )
    Surface(
        modifier = baseModifier,
        shape = shape,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun StatusPulseBadge(
    label: String,
    isActive: Boolean,
    activeColor: Color = CyberGreenActive,
    inactiveColor: Color = CyberBluePrimary,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )
    val targetColor by animateColorAsState(
        targetValue = when {
            isError -> CyberRedDanger
            isActive -> activeColor
            else -> inactiveColor
        },
        label = "badge_color"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(targetColor.copy(alpha = 0.14f))
            .border(1.dp, targetColor.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(
                    if (isActive) targetColor.copy(alpha = pulseAlpha) else targetColor
                )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = targetColor,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun CyberActionTile(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = CyberSurfaceElevated.copy(alpha = 0.94f),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.horizontalGradient(
                listOf(accentColor.copy(alpha = 0.75f), CyberBorderGlow)
            )
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accentColor.copy(alpha = 0.16f))
                    .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(30.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = badge,
                    fontFamily = CyberMonoFamily,
                    fontSize = 11.sp,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary
                )
            }
        }
    }
}

@Composable
fun TerminalLogBox(
    logs: List<String>,
    modifier: Modifier = Modifier
) {
    CyberHudCard(
        modifier = modifier.fillMaxWidth(),
        borderColor = CyberBlueCobalt.copy(alpha = 0.45f),
        containerColor = Color(0xFF040812)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SYS://SECURITY_TERMINAL_LOG",
                fontFamily = CyberMonoFamily,
                fontSize = 11.sp,
                color = CyberBluePrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "TLS/DTLS",
                fontFamily = CyberMonoFamily,
                fontSize = 10.sp,
                color = CyberGreenActive
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (logs.isEmpty()) {
            Text(
                text = "> কোনো সক্রিয় লগ নেই — সেশন শুরু করতে মোড নির্বাচন করুন।",
                fontFamily = CyberMonoFamily,
                fontSize = 11.sp,
                color = CyberTextSecondary
            )
        } else {
            logs.takeLast(5).forEach { line ->
                Text(
                    text = "> $line",
                    fontFamily = CyberMonoFamily,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = CyberTextPrimary.copy(alpha = 0.9f),
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
        }
    }
}

package com.example.data

import android.content.Context
import android.os.Build
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.security.SecureRandom

private val Context.dataStore by preferencesDataStore(name = "drc_security_prefs")

object ServerConfigStore {
    private val KEY_SIGNALING_URL = stringPreferencesKey("signaling_ws_url")
    private val KEY_DEVICE_LABEL = stringPreferencesKey("device_label")

    // Default secure WebSocket endpoint (user can configure LAN/Cloud WSS server in Dashboard)
    const val DEFAULT_SIGNALING_URL = "wss://drc-signaling.example.com:8443"

    private val CODE_CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray()
    private val secureRandom = SecureRandom()

    fun signalingUrlFlow(context: Context): Flow<String> =
        context.dataStore.data.map { prefs ->
            prefs[KEY_SIGNALING_URL]?.takeIf { it.isNotBlank() } ?: DEFAULT_SIGNALING_URL
        }

    fun deviceLabelFlow(context: Context): Flow<String> =
        context.dataStore.data.map { prefs ->
            prefs[KEY_DEVICE_LABEL]?.takeIf { it.isNotBlank() } ?: defaultDeviceName()
        }

    suspend fun saveSignalingUrl(context: Context, url: String) {
        val cleaned = url.trim()
        if (cleaned.startsWith("wss://") || cleaned.startsWith("ws://")) {
            context.dataStore.edit { prefs ->
                prefs[KEY_SIGNALING_URL] = cleaned
            }
        }
    }

    suspend fun saveDeviceLabel(context: Context, label: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DEVICE_LABEL] = label.trim().ifEmpty { defaultDeviceName() }
        }
    }

    fun defaultDeviceName(): String {
        val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return "$brand $model".take(28)
    }

    /**
     * Generates a single-use cryptographic pairing code formatted as XXXX-XXXX.
     */
    fun generateOneTimeCode(): String {
        val chars = CharArray(8)
        for (i in chars.indices) {
            chars[i] = CODE_CHARSET[secureRandom.nextInt(CODE_CHARSET.size)]
        }
        val raw = String(chars)
        return "${raw.substring(0, 4)}-${raw.substring(4, 8)}"
    }

    fun normalizeCode(input: String): String {
        val clean = input.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }
        return if (clean.length == 8) {
            "${clean.substring(0, 4)}-${clean.substring(4, 8)}"
        } else {
            clean
        }
    }
}

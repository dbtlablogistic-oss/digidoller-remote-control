package com.example.webrtc

import org.json.JSONObject
import org.webrtc.DataChannel
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection

object WebRtcConfig {

    const val DATA_CHANNEL_LABEL = "drc-assist-channel"
    const val CAPTURE_MAX_WIDTH = 720
    const val CAPTURE_MAX_HEIGHT = 1280
    const val CAPTURE_FPS = 24

    fun createIceServers(): List<PeerConnection.IceServer> {
        return listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
        )
    }

    fun createRtcConfiguration(): PeerConnection.RTCConfiguration {
        return PeerConnection.RTCConfiguration(createIceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            iceCandidatePoolSize = 4
        }
    }

    fun createOfferAnswerConstraints(): MediaConstraints {
        return MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
    }

    fun createDataChannelInit(): DataChannel.Init {
        return DataChannel.Init().apply {
            ordered = true
            maxRetransmits = 3
        }
    }
}

enum class SessionRole {
    CONTROLLER, // Mobile A
    HOST        // Mobile B
}

enum class ConnectionPhase(val labelBn: String) {
    IDLE("প্রস্তুত"),
    CONNECTING_SERVER("সিগন্যালিং সার্ভারে যুক্ত হচ্ছে..."),
    WAITING_FOR_PEER("সংযোগ কোডের অপেক্ষায়"),
    PENDING_APPROVAL("অনুমতির অপেক্ষায়..."),
    AUTHORIZED("অনুমতি প্রাপ্ত — WebRTC শুরু হচ্ছে"),
    CONNECTED("লাইভ সেশন সংযুক্ত"),
    DISCONNECTED("সংযোগ বিচ্ছিন্ন"),
    ERROR("সংযোগ ত্রুটি")
}

data class RemoteAssistEvent(
    val type: String,       // "POINTER", "CLEAR_POINTER", "HEARTBEAT", "END_SESSION"
    val xNorm: Float = 0f,
    val yNorm: Float = 0f,
    val label: String = "",
    val timestampMs: Long = System.currentTimeMillis()
) {
    fun toJsonString(): String {
        return JSONObject().apply {
            put("type", type)
            put("x", xNorm.toDouble())
            put("y", yNorm.toDouble())
            put("label", label)
            put("ts", timestampMs)
        }.toString()
    }

    companion object {
        fun fromJsonString(raw: String): RemoteAssistEvent? {
            return try {
                val obj = JSONObject(raw)
                RemoteAssistEvent(
                    type = obj.optString("type", "UNKNOWN"),
                    xNorm = obj.optDouble("x", 0.0).toFloat(),
                    yNorm = obj.optDouble("y", 0.0).toFloat(),
                    label = obj.optString("label", ""),
                    timestampMs = obj.optLong("ts", System.currentTimeMillis())
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

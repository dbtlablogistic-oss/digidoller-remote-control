package com.example.webrtc

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets

interface WebRtcCallbacks {
    fun onLocalOfferCreated(sdp: String)
    fun onLocalAnswerCreated(sdp: String)
    fun onIceCandidateGenerated(sdpMid: String, sdpMLineIndex: Int, candidate: String)
    fun onIceConnectionChanged(state: PeerConnection.IceConnectionState)
    fun onAssistEventReceived(event: RemoteAssistEvent)
    fun onMediaProjectionStoppedBySystem()
    fun onError(message: String)
}

class WebRtcManager(
    private val context: Context,
    private val callbacks: WebRtcCallbacks
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null

    private var videoCapturer: VideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var dataChannel: DataChannel? = null

    private val pendingIceCandidates = mutableListOf<IceCandidate>()
    private var isRemoteSdpSet = false

    private val _iceState = MutableStateFlow(PeerConnection.IceConnectionState.NEW)
    val iceState: StateFlow<PeerConnection.IceConnectionState> = _iceState.asStateFlow()

    fun initializeFactory() {
        if (peerConnectionFactory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        val egl = EglBase.create()
        eglBase = egl
        val encoderFactory = DefaultVideoEncoderFactory(egl.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(egl.eglBaseContext)
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()
    }

    fun getEglContext(): EglBase.Context? {
        initializeFactory()
        return eglBase?.eglBaseContext
    }

    fun attachRemoteRenderer(renderer: SurfaceViewRenderer) {
        initializeFactory()
        val eglCtx = eglBase?.eglBaseContext ?: return
        if (remoteRenderer !== renderer) {
            renderer.init(eglCtx, null)
            renderer.setEnableHardwareScaler(true)
            renderer.setMirror(false)
            remoteRenderer = renderer
            remoteVideoTrack?.addSink(renderer)
        }
    }

    fun createPeerConnection(isController: Boolean) {
        initializeFactory()
        val factory = peerConnectionFactory ?: return
        isRemoteSdpSet = false
        pendingIceCandidates.clear()

        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                newState ?: return
                _iceState.value = newState
                mainHandler.post { callbacks.onIceConnectionChanged(newState) }
            }

            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}

            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate ?: return
                callbacks.onIceCandidateGenerated(
                    candidate.sdpMid ?: "",
                    candidate.sdpMLineIndex,
                    candidate.sdp
                )
            }

            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}

            override fun onAddStream(stream: MediaStream?) {
                val track = stream?.videoTracks?.firstOrNull() ?: return
                attachRemoteTrack(track)
            }

            override fun onRemoveStream(stream: MediaStream?) {}

            override fun onDataChannel(dc: DataChannel?) {
                dc?.let { registerDataChannelObserver(it) }
            }

            override fun onRenegotiationNeeded() {}

            override fun onTrack(transceiver: RtpTransceiver?) {
                val track = transceiver?.receiver?.track() as? VideoTrack ?: return
                attachRemoteTrack(track)
            }
        }

        val pc = factory.createPeerConnection(WebRtcConfig.createRtcConfiguration(), observer)
        if (pc == null) {
            callbacks.onError("WebRTC PeerConnection তৈরি করা যায়নি।")
            return
        }
        peerConnection = pc

        if (isController) {
            val dc = pc.createDataChannel(
                WebRtcConfig.DATA_CHANNEL_LABEL,
                WebRtcConfig.createDataChannelInit()
            )
            dc?.let { registerDataChannelObserver(it) }
        }
    }

    private fun attachRemoteTrack(track: VideoTrack) {
        remoteVideoTrack = track
        mainHandler.post {
            remoteRenderer?.let { renderer ->
                track.addSink(renderer)
            }
        }
    }

    private fun registerDataChannelObserver(channel: DataChannel) {
        dataChannel = channel
        channel.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {}
            override fun onStateChange() {}
            override fun onMessage(buffer: DataChannel.Buffer?) {
                buffer ?: return
                val bytes = ByteArray(buffer.data.remaining())
                buffer.data.get(bytes)
                val text = String(bytes, StandardCharsets.UTF_8)
                RemoteAssistEvent.fromJsonString(text)?.let { event ->
                    mainHandler.post { callbacks.onAssistEventReceived(event) }
                }
            }
        })
    }

    fun startScreenCaptureAndAttachTrack(mediaProjectionResultData: Intent) {
        initializeFactory()
        val factory = peerConnectionFactory ?: return
        val eglCtx = eglBase?.eglBaseContext ?: return

        stopScreenCaptureOnly()

        val projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { callbacks.onMediaProjectionStoppedBySystem() }
            }
        }

        val capturer = ScreenCapturerAndroid(mediaProjectionResultData, projectionCallback)
        val textureHelper = SurfaceTextureHelper.create("DrcScreenCapture", eglCtx)
        val source = factory.createVideoSource(true)

        capturer.initialize(textureHelper, context.applicationContext, source.capturerObserver)
        capturer.startCapture(
            WebRtcConfig.CAPTURE_MAX_WIDTH,
            WebRtcConfig.CAPTURE_MAX_HEIGHT,
            WebRtcConfig.CAPTURE_FPS
        )

        val track = factory.createVideoTrack("DRC_SCREEN_VIDEO", source)
        track.setEnabled(true)

        videoCapturer = capturer
        surfaceTextureHelper = textureHelper
        videoSource = source
        localVideoTrack = track

        peerConnection?.addTrack(track, listOf("DRC_STREAM"))
    }

    fun createOffer() {
        val pc = peerConnection ?: return
        pc.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp ?: return
                pc.setLocalDescription(simpleSdpObserver("setLocalOffer"), sdp)
                callbacks.onLocalOfferCreated(sdp.description)
            }

            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) {
                callbacks.onError("Offer তৈরি ব্যর্থ: ${error.orEmpty()}")
            }

            override fun onSetFailure(error: String?) {}
        }, WebRtcConfig.createOfferAnswerConstraints())
    }

    fun onRemoteOfferReceived(sdpText: String) {
        val pc = peerConnection ?: return
        val remoteSdp = SessionDescription(SessionDescription.Type.OFFER, sdpText)
        pc.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {}
            override fun onSetSuccess() {
                isRemoteSdpSet = true
                drainPendingIceCandidates()
                createAnswer()
            }

            override fun onCreateFailure(error: String?) {}
            override fun onSetFailure(error: String?) {
                callbacks.onError("Remote Offer সেট ব্যর্থ: ${error.orEmpty()}")
            }
        }, remoteSdp)
    }

    private fun createAnswer() {
        val pc = peerConnection ?: return
        pc.createAnswer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp ?: return
                pc.setLocalDescription(simpleSdpObserver("setLocalAnswer"), sdp)
                callbacks.onLocalAnswerCreated(sdp.description)
            }

            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) {
                callbacks.onError("Answer তৈরি ব্যর্থ: ${error.orEmpty()}")
            }

            override fun onSetFailure(error: String?) {}
        }, WebRtcConfig.createOfferAnswerConstraints())
    }

    fun onRemoteAnswerReceived(sdpText: String) {
        val pc = peerConnection ?: return
        val remoteSdp = SessionDescription(SessionDescription.Type.ANSWER, sdpText)
        pc.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {}
            override fun onSetSuccess() {
                isRemoteSdpSet = true
                drainPendingIceCandidates()
            }

            override fun onCreateFailure(error: String?) {}
            override fun onSetFailure(error: String?) {
                callbacks.onError("Remote Answer সেট ব্যর্থ: ${error.orEmpty()}")
            }
        }, remoteSdp)
    }

    fun addRemoteIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        val ice = IceCandidate(sdpMid, sdpMLineIndex, candidate)
        if (isRemoteSdpSet) {
            peerConnection?.addIceCandidate(ice)
        } else {
            pendingIceCandidates.add(ice)
        }
    }

    private fun drainPendingIceCandidates() {
        val pc = peerConnection ?: return
        pendingIceCandidates.forEach { pc.addIceCandidate(it) }
        pendingIceCandidates.clear()
    }

    fun sendAssistEvent(event: RemoteAssistEvent): Boolean {
        val channel = dataChannel ?: return false
        if (channel.state() != DataChannel.State.OPEN) return false
        val bytes = event.toJsonString().toByteArray(StandardCharsets.UTF_8)
        return channel.send(DataChannel.Buffer(ByteBuffer.wrap(bytes), false))
    }

    private fun simpleSdpObserver(tag: String) = object : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {
            callbacks.onError("$tag ব্যর্থ: ${error.orEmpty()}")
        }

        override fun onSetFailure(error: String?) {
            callbacks.onError("$tag সেট ব্যর্থ: ${error.orEmpty()}")
        }
    }

    private fun stopScreenCaptureOnly() {
        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) {
        }
        try {
            videoCapturer?.dispose()
        } catch (_: Exception) {
        }
        videoCapturer = null
        try {
            surfaceTextureHelper?.dispose()
        } catch (_: Exception) {
        }
        surfaceTextureHelper = null
        try {
            videoSource?.dispose()
        } catch (_: Exception) {
        }
        videoSource = null
        localVideoTrack = null
    }

    fun releaseSession() {
        stopScreenCaptureOnly()
        remoteRenderer?.let { renderer ->
            try {
                remoteVideoTrack?.removeSink(renderer)
            } catch (_: Exception) {
            }
        }
        remoteVideoTrack = null
        try {
            dataChannel?.unregisterObserver()
            dataChannel?.close()
            dataChannel?.dispose()
        } catch (_: Exception) {
        }
        dataChannel = null
        try {
            peerConnection?.close()
            peerConnection?.dispose()
        } catch (_: Exception) {
        }
        peerConnection = null
        pendingIceCandidates.clear()
        isRemoteSdpSet = false
        _iceState.value = PeerConnection.IceConnectionState.CLOSED
    }

    fun releaseAll() {
        releaseSession()
        try {
            remoteRenderer?.release()
        } catch (_: Exception) {
        }
        remoteRenderer = null
        try {
            peerConnectionFactory?.dispose()
        } catch (_: Exception) {
        }
        peerConnectionFactory = null
        try {
            eglBase?.release()
        } catch (_: Exception) {
        }
        eglBase = null
    }
}

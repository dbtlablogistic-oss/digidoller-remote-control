package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ServerConfigStore
import com.example.network.SignalingClient
import com.example.network.SignalingEvent
import com.example.qr.QrCodeHelper
import com.example.qr.QrCodeScannerView
import com.example.ui.components.CyberGridBackground
import com.example.ui.components.CyberHudCard
import com.example.ui.components.StatusPulseBadge
import com.example.ui.components.TerminalLogBox
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBlueCobalt
import com.example.ui.theme.CyberBluePrimary
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberMonoFamily
import com.example.ui.theme.CyberRedDanger
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DigidollerTheme
import com.example.webrtc.ConnectionPhase
import com.example.webrtc.RemoteAssistEvent
import com.example.webrtc.WebRtcCallbacks
import com.example.webrtc.WebRtcManager
import kotlinx.coroutines.launch
import org.webrtc.PeerConnection
import org.webrtc.SurfaceViewRenderer

class ControllerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DigidollerTheme {
                ControllerScreen(onNavigateBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ControllerScreen(onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedServerUrl by ServerConfigStore.signalingUrlFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.DEFAULT_SIGNALING_URL)
    val deviceName by ServerConfigStore.deviceLabelFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.defaultDeviceName())

    var pairingCodeInput by remember { mutableStateOf("") }
    var activeServerUrl by remember { mutableStateOf<String?>(null) }
    var connectedHostName by remember { mutableStateOf<String?>(null) }
    var statusNotice by remember { mutableStateOf<String?>(null) }
    var showQrScanner by remember { mutableStateOf(false) }
    var assistPointer by remember { mutableStateOf<Offset?>(null) }
    var pointerAssistEnabled by remember { mutableStateOf(true) }

    val signalingClient = remember { SignalingClient() }
    val phase by signalingClient.phase.collectAsStateWithLifecycle()
    val logs by signalingClient.logs.collectAsStateWithLifecycle()

    val webRtcManager = remember {
        WebRtcManager(
            context = context,
            callbacks = object : WebRtcCallbacks {
                override fun onLocalOfferCreated(sdp: String) {
                    signalingClient.sendOffer(sdp)
                }

                override fun onLocalAnswerCreated(sdp: String) {
                    signalingClient.sendAnswer(sdp)
                }

                override fun onIceCandidateGenerated(
                    sdpMid: String,
                    sdpMLineIndex: Int,
                    candidate: String
                ) {
                    signalingClient.sendIceCandidate(sdpMid, sdpMLineIndex, candidate)
                }

                override fun onIceConnectionChanged(state: PeerConnection.IceConnectionState) {
                    signalingClient.appendLog("WebRTC ICE অবস্থা: $state")
                    when (state) {
                        PeerConnection.IceConnectionState.CONNECTED,
                        PeerConnection.IceConnectionState.COMPLETED -> {
                            signalingClient.updatePhase(ConnectionPhase.CONNECTED)
                            statusNotice = "লাইভ স্ক্রিন সংযুক্ত হয়েছে।"
                        }

                        PeerConnection.IceConnectionState.DISCONNECTED,
                        PeerConnection.IceConnectionState.FAILED,
                        PeerConnection.IceConnectionState.CLOSED -> {
                            if (phase == ConnectionPhase.CONNECTED) {
                                signalingClient.updatePhase(ConnectionPhase.DISCONNECTED)
                            }
                        }

                        else -> Unit
                    }
                }

                override fun onAssistEventReceived(event: RemoteAssistEvent) {
                    if (event.type == "END_SESSION") {
                        statusNotice = "Mobile B সেশন বন্ধ করেছে।"
                    }
                }

                override fun onMediaProjectionStoppedBySystem() {}

                override fun onError(message: String) {
                    signalingClient.appendLog(message)
                    statusNotice = message
                }
            }
        )
    }

    val iceState by webRtcManager.iceState.collectAsStateWithLifecycle()

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            showQrScanner = true
        } else {
            statusNotice = "QR কোড স্ক্যান করতে ক্যামেরার অনুমতি প্রয়োজন।"
        }
    }

    LaunchedEffect(signalingClient) {
        signalingClient.events.collect { event ->
            when (event) {
                is SignalingEvent.PairApproved -> {
                    connectedHostName = event.hostName
                    statusNotice = "${event.hostName} সংযোগের অনুমতি দিয়েছে।"
                    webRtcManager.createPeerConnection(isController = true)
                    webRtcManager.createOffer()
                }

                is SignalingEvent.PairRejected -> {
                    statusNotice = event.reason
                    webRtcManager.releaseSession()
                }

                is SignalingEvent.AnswerReceived -> {
                    webRtcManager.onRemoteAnswerReceived(event.sdp)
                }

                is SignalingEvent.IceCandidateReceived -> {
                    webRtcManager.addRemoteIceCandidate(
                        event.sdpMid,
                        event.sdpMLineIndex,
                        event.candidate
                    )
                }

                is SignalingEvent.PeerDisconnected -> {
                    statusNotice = event.reason
                    connectedHostName = null
                    assistPointer = null
                    webRtcManager.releaseSession()
                }

                is SignalingEvent.ServerError -> {
                    statusNotice = event.message
                }

                else -> Unit
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            signalingClient.disconnect(sendSignal = true)
            webRtcManager.releaseAll()
        }
    }

    fun startConnection(codeOverride: String? = null, serverOverride: String? = null) {
        val code = ServerConfigStore.normalizeCode(codeOverride ?: pairingCodeInput)
        if (code.length < 6) {
            statusNotice = "সঠিক One-Time Connection Code দিন।"
            return
        }
        pairingCodeInput = code
        val targetServer = serverOverride ?: activeServerUrl ?: savedServerUrl
        statusNotice = "Mobile B-এর অনুমতির জন্য অনুরোধ পাঠানো হয়েছে..."
        signalingClient.connectAsController(targetServer, code, deviceName)
    }

    fun endSession() {
        webRtcManager.sendAssistEvent(RemoteAssistEvent(type = "END_SESSION"))
        signalingClient.disconnect(sendSignal = true)
        webRtcManager.releaseSession()
        connectedHostName = null
        assistPointer = null
        statusNotice = "সেশন বিচ্ছিন্ন করা হয়েছে।"
    }

    Scaffold(
        containerColor = CyberBlack,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        CyberGridBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 700.dp)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Top App Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    endSession()
                                    onNavigateBack()
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("btn_back_controller")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "পিছনে যান",
                                    tint = CyberBluePrimary
                                )
                            }
                            Column {
                                Text(
                                    text = "MOBILE A // কন্ট্রোলার",
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 11.sp,
                                    color = CyberBluePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "রিমোট সেশন কন্ট্রোল",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CyberTextPrimary
                                )
                            }
                        }
                        StatusPulseBadge(
                            label = phase.labelBn,
                            isActive = phase == ConnectionPhase.CONNECTED ||
                                phase == ConnectionPhase.PENDING_APPROVAL,
                            isError = phase == ConnectionPhase.ERROR,
                            activeColor = if (phase == ConnectionPhase.CONNECTED) {
                                CyberGreenActive
                            } else {
                                CyberBluePrimary
                            }
                        )
                    }

                    // Notice Banner
                    if (statusNotice != null) {
                        CyberHudCard(
                            borderColor = if (phase == ConnectionPhase.ERROR) CyberRedDanger else CyberBluePrimary
                        ) {
                            Text(
                                text = statusNotice!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextPrimary
                            )
                        }
                    }

                    // Pairing Card (Always visible when not actively viewing live stream)
                    if (phase != ConnectionPhase.CONNECTED && phase != ConnectionPhase.AUTHORIZED) {
                        CyberHudCard(borderColor = CyberBluePrimary.copy(alpha = 0.55f)) {
                            Text(
                                text = "Mobile B পেয়ারিং কোড বা QR স্ক্যান",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Mobile B ফোনে প্রদর্শিত One-Time Code লিখুন অথবা ক্যামেরা দিয়ে QR কোড স্ক্যান করুন।",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextSecondary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = pairingCodeInput,
                                onValueChange = { pairingCodeInput = it.uppercase().take(9) },
                                label = { Text("One-Time Connection Code (যেমন: ABCD-1234)") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_pairing_code"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberBluePrimary,
                                    unfocusedBorderColor = CyberBorderGlow,
                                    focusedTextColor = CyberTextPrimary,
                                    unfocusedTextColor = CyberTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val granted = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (granted) {
                                            showQrScanner = true
                                        } else {
                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .testTag("btn_scan_qr")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.QrCodeScanner,
                                        contentDescription = "QR স্ক্যান",
                                        tint = CyberBluePrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("QR স্ক্যান", color = CyberBluePrimary)
                                }

                                Button(
                                    onClick = { startConnection() },
                                    enabled = phase != ConnectionPhase.CONNECTING_SERVER &&
                                        phase != ConnectionPhase.PENDING_APPROVAL,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyberBluePrimary,
                                        contentColor = CyberBlack
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp)
                                        .testTag("btn_connect_host")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Link,
                                        contentDescription = "সংযোগ"
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("সংযোগ করুন")
                                }
                            }
                            if (phase == ConnectionPhase.PENDING_APPROVAL ||
                                phase == ConnectionPhase.CONNECTING_SERVER
                            ) {
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { endSession() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_cancel_pending")
                                ) {
                                    Text("অনুরোধ বাতিল করুন", color = CyberRedDanger)
                                }
                            }
                        }
                    }

                    // Live Remote Screen Viewport
                    CyberHudCard(
                        borderColor = if (phase == ConnectionPhase.CONNECTED) {
                            CyberGreenActive
                        } else {
                            CyberBorderGlow
                        }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = connectedHostName?.let { "লাইভ স্ক্রিন: $it" }
                                        ?: "লাইভ স্ক্রিন প্রিভিউ",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberTextPrimary
                                )
                                Text(
                                    text = "ICE: $iceState",
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 11.sp,
                                    color = CyberBluePrimary
                                )
                            }
                            if (phase == ConnectionPhase.CONNECTED) {
                                StatusPulseBadge(
                                    label = "LIVE",
                                    isActive = true,
                                    activeColor = CyberGreenActive
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        var viewportSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(9f / 16f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF03060D))
                                .border(1.dp, CyberBorderGlow, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (phase == ConnectionPhase.AUTHORIZED || phase == ConnectionPhase.CONNECTED) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    AndroidView(
                                        factory = { ctx ->
                                            SurfaceViewRenderer(ctx).also { renderer ->
                                                webRtcManager.attachRemoteRenderer(renderer)
                                            }
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Canvas(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .pointerInteropFilter { motion ->
                                                if (pointerAssistEnabled &&
                                                    phase == ConnectionPhase.CONNECTED &&
                                                    viewportSize.width > 0 &&
                                                    viewportSize.height > 0 &&
                                                    (motion.action == MotionEvent.ACTION_DOWN ||
                                                        motion.action == MotionEvent.ACTION_MOVE)
                                                ) {
                                                    val pt = Offset(motion.x, motion.y)
                                                    assistPointer = pt
                                                    val xNorm = (pt.x / viewportSize.width).coerceIn(0f, 1f)
                                                    val yNorm = (pt.y / viewportSize.height).coerceIn(0f, 1f)
                                                    webRtcManager.sendAssistEvent(
                                                        RemoteAssistEvent(
                                                            type = "POINTER",
                                                            xNorm = xNorm,
                                                            yNorm = yNorm,
                                                            label = deviceName
                                                        )
                                                    )
                                                    true
                                                } else {
                                                    false
                                                }
                                            }
                                            .onSizeChanged { viewportSize = it }
                                    ) {
                                        assistPointer?.let { pt ->
                                            drawCircle(
                                                color = CyberBluePrimary.copy(alpha = 0.25f),
                                                radius = 28.dp.toPx(),
                                                center = pt
                                            )
                                            drawCircle(
                                                color = CyberBluePrimary,
                                                radius = 14.dp.toPx(),
                                                center = pt,
                                                style = Stroke(width = 3.dp.toPx())
                                            )
                                            drawCircle(
                                                color = CyberGreenActive,
                                                radius = 5.dp.toPx(),
                                                center = pt
                                            )
                                        }
                                    }
                                }
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.TouchApp,
                                        contentDescription = "কোনো লাইভ স্ট্রিম নেই",
                                        tint = CyberBlueCobalt,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Text(
                                        text = "Mobile B অনুমোদন দিলে এখানে লাইভ স্ক্রিন দেখা যাবে",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = CyberTextSecondary
                                    )
                                }
                            }
                        }

                        if (phase == ConnectionPhase.CONNECTED || phase == ConnectionPhase.AUTHORIZED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        pointerAssistEnabled = !pointerAssistEnabled
                                        if (!pointerAssistEnabled) {
                                            assistPointer = null
                                            webRtcManager.sendAssistEvent(
                                                RemoteAssistEvent(type = "CLEAR_POINTER")
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("btn_toggle_pointer")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MyLocation,
                                        contentDescription = "পয়েন্টার",
                                        tint = CyberBluePrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (pointerAssistEnabled) "পয়েন্টার চালু" else "পয়েন্টার বন্ধ",
                                        color = CyberBluePrimary
                                    )
                                }

                                Button(
                                    onClick = { endSession() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyberRedDanger,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("btn_disconnect_session")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CallEnd,
                                        contentDescription = "সংযোগ বিচ্ছিন্ন"
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("সংযোগ বিচ্ছিন্ন")
                                }
                            }
                        }
                    }

                    // Live Terminal Logs
                    TerminalLogBox(logs = logs)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }

    if (showQrScanner) {
        AlertDialog(
            onDismissRequest = { showQrScanner = false },
            containerColor = CyberSurfaceElevated,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "QR কোড স্ক্যান করুন",
                        style = MaterialTheme.typography.titleLarge,
                        color = CyberTextPrimary
                    )
                    IconButton(onClick = { showQrScanner = false }) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "বন্ধ করুন",
                            tint = CyberTextSecondary
                        )
                    }
                }
            },
            text = {
                QrCodeScannerView(
                    onQrDetected = { rawQr ->
                        val parsed = QrCodeHelper.parsePairingPayload(rawQr)
                        showQrScanner = false
                        if (parsed != null) {
                            parsed.serverUrl?.let { url ->
                                activeServerUrl = url
                                scope.launch {
                                    ServerConfigStore.saveSignalingUrl(context, url)
                                }
                            }
                            startConnection(codeOverride = parsed.code, serverOverride = parsed.serverUrl)
                        } else {
                            statusNotice = "অকার্যকর QR কোড শনাক্ত হয়েছে।"
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = { showQrScanner = false }) {
                    Text("বাতিল", color = CyberBluePrimary)
                }
            }
        )
    }
}

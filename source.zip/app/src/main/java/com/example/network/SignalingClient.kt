package com.example.network

import com.example.webrtc.ConnectionPhase
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class SignalingEvent {
    data class HostRegistered(val code: String, val expiresInSec: Int) : SignalingEvent()
    data class IncomingPairRequest(
        val controllerId: String,
        val controllerName: String,
        val code: String
    ) : SignalingEvent()

    data class PairApproved(val hostName: String, val sessionToken: String) : SignalingEvent()
    data class PairRejected(val reason: String) : SignalingEvent()
    data class OfferReceived(val sdp: String) : SignalingEvent()
    data class AnswerReceived(val sdp: String) : SignalingEvent()
    data class IceCandidateReceived(
        val sdpMid: String,
        val sdpMLineIndex: Int,
        val candidate: String
    ) : SignalingEvent()

    data class PeerDisconnected(val reason: String) : SignalingEvent()
    data class ServerError(val message: String) : SignalingEvent()
}

class SignalingClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var activeCode: String = ""
    private var isHostRole: Boolean = false
    private var deviceName: String = "DRC Device"

    private val _phase = MutableStateFlow(ConnectionPhase.IDLE)
    val phase: StateFlow<ConnectionPhase> = _phase.asStateFlow()

    private val _events = MutableSharedFlow<SignalingEvent>(extraBufferCapacity = 32)
    val events: SharedFlow<SignalingEvent> = _events.asSharedFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    fun connectAsHost(serverUrl: String, oneTimeCode: String, hostName: String) {
        isHostRole = true
        activeCode = oneTimeCode
        deviceName = hostName
        openSocket(serverUrl)
    }

    fun connectAsController(serverUrl: String, oneTimeCode: String, controllerName: String) {
        isHostRole = false
        activeCode = oneTimeCode
        deviceName = controllerName
        openSocket(serverUrl)
    }

    private fun openSocket(serverUrl: String) {
        disconnect(sendSignal = false)
        val trimmed = serverUrl.trim()
        if (!trimmed.startsWith("wss://") && !trimmed.startsWith("ws://")) {
            _phase.value = ConnectionPhase.ERROR
            appendLog("ত্রুটি: সার্ভার URL অবশ্যই wss:// বা ws:// হতে হবে")
            _events.tryEmit(SignalingEvent.ServerError("সার্ভার URL সঠিক নয় (wss:// প্রয়োজন)।"))
            return
        }

        _phase.value = ConnectionPhase.CONNECTING_SERVER
        appendLog("সিগন্যালিং সার্ভারে সংযোগ চেষ্টা: $trimmed")

        val request = Request.Builder()
            .url(trimmed)
            .header("X-DRC-Version", "1.0")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                appendLog("WebSocket চ্যানেল স্থাপিত হয়েছে")
                if (isHostRole) {
                    _phase.value = ConnectionPhase.WAITING_FOR_PEER
                    sendJson(
                        JSONObject().apply {
                            put("type", "REGISTER_HOST")
                            put("code", activeCode)
                            put("deviceName", deviceName)
                        }
                    )
                } else {
                    _phase.value = ConnectionPhase.PENDING_APPROVAL
                    sendJson(
                        JSONObject().apply {
                            put("type", "PAIR_REQUEST")
                            put("code", activeCode)
                            put("deviceName", deviceName)
                        }
                    )
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                appendLog("সার্ভার সংযোগ বন্ধ করছে ($code)")
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (_phase.value != ConnectionPhase.ERROR) {
                    _phase.value = ConnectionPhase.DISCONNECTED
                }
                appendLog("WebSocket সংযোগ বিচ্ছিন্ন")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _phase.value = ConnectionPhase.ERROR
                val msg = t.localizedMessage ?: "সিগন্যালিং সার্ভারে পৌঁছানো যায়নি"
                appendLog("নেটওয়ার্ক ত্রুটি: $msg")
                _events.tryEmit(SignalingEvent.ServerError("সার্ভার সংযোগ ব্যর্থ: $msg"))
            }
        })
    }

    private fun handleIncomingMessage(raw: String) {
        try {
            val json = JSONObject(raw)
            when (json.optString("type")) {
                "HOST_REGISTERED" -> {
                    val code = json.optString("code", activeCode)
                    val ttl = json.optInt("expiresInSec", 300)
                    appendLog("হোস্ট কোড নিবন্ধিত: $code (${ttl}s)")
                    _events.tryEmit(SignalingEvent.HostRegistered(code, ttl))
                }

                "PAIR_REQUEST" -> {
                    val controllerId = json.optString("controllerId", "CTRL-UNKNOWN")
                    val controllerName = json.optString("deviceName", "অজানা ডিভাইস")
                    val code = json.optString("code", activeCode)
                    _phase.value = ConnectionPhase.PENDING_APPROVAL
                    appendLog("নতুন সংযোগ অনুরোধ: $controllerName")
                    _events.tryEmit(
                        SignalingEvent.IncomingPairRequest(controllerId, controllerName, code)
                    )
                }

                "PAIR_APPROVED" -> {
                    val hostName = json.optString("hostName", "Mobile B")
                    val token = json.optString("sessionToken", "")
                    _phase.value = ConnectionPhase.AUTHORIZED
                    appendLog("হোস্ট অনুমতি দিয়েছেন — সেশন অনুমোদিত")
                    _events.tryEmit(SignalingEvent.PairApproved(hostName, token))
                }

                "PAIR_REJECTED" -> {
                    val reason = json.optString("reason", "ব্যবহারকারী সংযোগ প্রত্যাখ্যান করেছেন")
                    _phase.value = ConnectionPhase.DISCONNECTED
                    appendLog("সংযোগ প্রত্যাখ্যাত: $reason")
                    _events.tryEmit(SignalingEvent.PairRejected(reason))
                }

                "OFFER" -> {
                    val sdp = json.optString("sdp", "")
                    if (sdp.isNotEmpty()) {
                        appendLog("SDP Offer প্রাপ্ত হয়েছে")
                        _events.tryEmit(SignalingEvent.OfferReceived(sdp))
                    }
                }

                "ANSWER" -> {
                    val sdp = json.optString("sdp", "")
                    if (sdp.isNotEmpty()) {
                        appendLog("SDP Answer প্রাপ্ত হয়েছে")
                        _events.tryEmit(SignalingEvent.AnswerReceived(sdp))
                    }
                }

                "ICE_CANDIDATE" -> {
                    val sdpMid = json.optString("sdpMid", "")
                    val sdpMLineIndex = json.optInt("sdpMLineIndex", 0)
                    val candidate = json.optString("candidate", "")
                    if (candidate.isNotEmpty()) {
                        _events.tryEmit(
                            SignalingEvent.IceCandidateReceived(sdpMid, sdpMLineIndex, candidate)
                        )
                    }
                }

                "PEER_DISCONNECTED" -> {
                    val reason = json.optString("reason", "অপর ডিভাইস সংযোগ বন্ধ করেছে")
                    _phase.value = ConnectionPhase.DISCONNECTED
                    appendLog("পিয়ার বিচ্ছিন্ন: $reason")
                    _events.tryEmit(SignalingEvent.PeerDisconnected(reason))
                }

                "ERROR" -> {
                    val msg = json.optString("message", "অজানা সার্ভার ত্রুটি")
                    _phase.value = ConnectionPhase.ERROR
                    appendLog("সার্ভার ত্রুটি: $msg")
                    _events.tryEmit(SignalingEvent.ServerError(msg))
                }
            }
        } catch (e: Exception) {
            appendLog("সিগন্যাল পার্সিং ত্রুটি: ${e.message}")
        }
    }

    fun sendPairDecision(controllerId: String, approved: Boolean, reason: String = "") {
        if (approved) {
            _phase.value = ConnectionPhase.AUTHORIZED
            appendLog("সংযোগ অনুমোদন পাঠানো হয়েছে")
        } else {
            _phase.value = ConnectionPhase.WAITING_FOR_PEER
            appendLog("সংযোগ প্রত্যাখ্যান করা হয়েছে")
        }
        sendJson(
            JSONObject().apply {
                put("type", "PAIR_DECISION")
                put("code", activeCode)
                put("controllerId", controllerId)
                put("approved", approved)
                put("hostName", deviceName)
                put("reason", reason)
            }
        )
    }

    fun sendOffer(sdp: String) {
        appendLog("SDP Offer পাঠানো হচ্ছে...")
        sendJson(
            JSONObject().apply {
                put("type", "OFFER")
                put("code", activeCode)
                put("sdp", sdp)
            }
        )
    }

    fun sendAnswer(sdp: String) {
        appendLog("SDP Answer পাঠানো হচ্ছে...")
        sendJson(
            JSONObject().apply {
                put("type", "ANSWER")
                put("code", activeCode)
                put("sdp", sdp)
            }
        )
    }

    fun sendIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        sendJson(
            JSONObject().apply {
                put("type", "ICE_CANDIDATE")
                put("code", activeCode)
                put("sdpMid", sdpMid)
                put("sdpMLineIndex", sdpMLineIndex)
                put("candidate", candidate)
            }
        )
    }

    fun updatePhase(phase: ConnectionPhase) {
        _phase.value = phase
    }

    fun appendLog(message: String) {
        val current = _logs.value
        _logs.value = (current + message).takeLast(30)
    }

    private fun sendJson(payload: JSONObject) {
        webSocket?.send(payload.toString())
    }

    fun disconnect(sendSignal: Boolean = true) {
        if (sendSignal && activeCode.isNotEmpty()) {
            sendJson(
                JSONObject().apply {
                    put("type", "DISCONNECT")
                    put("code", activeCode)
                }
            )
        }
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _phase.value = ConnectionPhase.DISCONNECTED
    }

    fun resetIdle() {
        _phase.value = ConnectionPhase.IDLE
    }
}

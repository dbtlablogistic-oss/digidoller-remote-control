package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ServerConfigStore
import com.example.ui.components.CyberActionTile
import com.example.ui.components.CyberGridBackground
import com.example.ui.components.CyberHudCard
import com.example.ui.components.StatusPulseBadge
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBlueCobalt
import com.example.ui.theme.CyberBluePrimary
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberMonoFamily
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DigidollerTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DigidollerTheme {
                DrcDashboardScreen(
                    onOpenController = {
                        startActivity(Intent(this, ControllerActivity::class.java))
                    },
                    onOpenScreenSharing = {
                        startActivity(Intent(this, ScreenSharingActivity::class.java))
                    }
                )
            }
        }
    }
}

@Composable
fun DrcDashboardScreen(
    onOpenController: () -> Unit,
    onOpenScreenSharing: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val savedServerUrl by ServerConfigStore.signalingUrlFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.DEFAULT_SIGNALING_URL)
    val savedDeviceLabel by ServerConfigStore.deviceLabelFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.defaultDeviceName())

    var showServerDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = CyberBlack,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        CyberGridBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 680.dp)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Top Cyber Status Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.drc_app_icon),
                                contentDescription = "DRC লোগো",
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, CyberBluePrimary.copy(alpha = 0.7f), RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "DRC // V1.0",
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 12.sp,
                                    color = CyberBluePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Digidoller Remote Control",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        StatusPulseBadge(
                            label = "SECURE",
                            isActive = true,
                            activeColor = CyberGreenActive
                        )
                    }

                    // Hero Cyber Command Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(148.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, CyberBluePrimary.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_drc_banner),
                            contentDescription = "সাইবার কমান্ড সেন্টার ব্যানার",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            CyberBlack.copy(alpha = 0.90f),
                                            CyberBlack.copy(alpha = 0.55f)
                                        )
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.align(Alignment.CenterStart),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "ANDROID-TO-ANDROID REMOTE ASSIST",
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 10.sp,
                                    color = CyberBluePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "নিরাপদ রিমোট স্ক্রিন ও সহায়তা",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = CyberTextPrimary
                                )
                                Text(
                                    text = "WebRTC এনক্রিপ্টেড চ্যানেল • অনুমতি ভিত্তিক সেশন",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                    }

                    // Role Selection Section Header
                    Text(
                        text = "ডিভাইস মোড নির্বাচন করুন",
                        style = MaterialTheme.typography.titleLarge,
                        color = CyberTextPrimary
                    )

                    // Mobile A - Controller
                    CyberActionTile(
                        title = "Mobile A — কন্ট্রোলার",
                        subtitle = "অন্য ফোনের লাইভ স্ক্রিন দেখুন, সংযোগ অবস্থা পর্যবেক্ষণ করুন এবং অনুমোদিত রিমোট সহায়তা দিন।",
                        badge = "MODE_A // REMOTE_VIEWER",
                        icon = Icons.Filled.DesktopWindows,
                        accentColor = CyberBluePrimary,
                        testTag = "btn_open_mobile_a",
                        onClick = onOpenController
                    )

                    // Mobile B - Screen Sharing
                    CyberActionTile(
                        title = "Mobile B — স্ক্রিন শেয়ারিং",
                        subtitle = "One-Time কোড বা QR কোড দিয়ে আপনার স্ক্রিন শেয়ার করুন। প্রতিটি সংযোগে আপনার অনুমতি লাগবে।",
                        badge = "MODE_B // SCREEN_HOST",
                        icon = Icons.Filled.Cast,
                        accentColor = CyberBlueCobalt,
                        testTag = "btn_open_mobile_b",
                        onClick = onOpenScreenSharing
                    )

                    // Signaling Server Card
                    CyberHudCard(
                        borderColor = CyberBlueCobalt.copy(alpha = 0.55f)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Dns,
                                    contentDescription = "সিগন্যালিং সার্ভার",
                                    tint = CyberBluePrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "নিরাপদ সিগন্যালিং সার্ভার (WebSocket)",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = CyberTextPrimary
                                    )
                                    Text(
                                        text = savedServerUrl,
                                        fontFamily = CyberMonoFamily,
                                        fontSize = 11.sp,
                                        color = CyberBluePrimary
                                    )
                                    Text(
                                        text = "ডিভাইস নাম: $savedDeviceLabel",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CyberTextSecondary
                                    )
                                }
                            }
                            IconButton(
                                onClick = { showServerDialog = true },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("btn_edit_server")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "সার্ভার কনফিগারেশন সম্পাদনা",
                                    tint = CyberBluePrimary
                                )
                            }
                        }
                    }

                    // Security Compliance Card
                    CyberHudCard(
                        borderColor = CyberGreenActive.copy(alpha = 0.45f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "নিরাপত্তা নীতিমালা",
                                tint = CyberGreenActive,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "সুরক্ষা ও গোপনীয়তা প্রোটোকল",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        SecurityBullet("অনুমতি ছাড়া কোনো ফোনে প্রবেশ বা স্ক্রিন দেখা সম্ভব নয়।")
                        SecurityBullet("গোপন স্ক্রিন রেকর্ডিং সম্পূর্ণ বন্ধ — সর্বদা সক্রিয় চিহ্ন থাকে।")
                        SecurityBullet("Android MediaProjection ও সিস্টেম পারমিশন কখনো বাইপাস করা হয় না।")
                        SecurityBullet("যেকোনো মুহূর্তে এক ক্লিকে পুরো সেশন বন্ধ করা যায়।")
                    }

                    // Developer & Owner Footer
                    CyberHudCard(
                        borderColor = CyberBorderGlow,
                        containerColor = Color(0xFF04070F)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.VerifiedUser,
                                    contentDescription = "ডেভেলপার তথ্য",
                                    tint = CyberBluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "ডেভেলপার ও অ্যাপ মালিক: Saheb",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = CyberTextPrimary
                                    )
                                    Text(
                                        text = "Digidoller Remote Control • DRC App V1.0",
                                        fontFamily = CyberMonoFamily,
                                        fontSize = 11.sp,
                                        color = CyberTextSecondary
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = "এনক্রিপ্টেড",
                                tint = CyberGreenActive,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }

    if (showServerDialog) {
        ServerConfigDialog(
            currentUrl = savedServerUrl,
            currentDeviceLabel = savedDeviceLabel,
            onDismiss = { showServerDialog = false },
            onSave = { newUrl, newLabel ->
                scope.launch {
                    ServerConfigStore.saveSignalingUrl(context, newUrl)
                    ServerConfigStore.saveDeviceLabel(context, newLabel)
                }
                showServerDialog = false
            }
        )
    }
}

@Composable
private fun SecurityBullet(text: String) {
    Row(
        modifier = Modifier.padding(vertical = 3.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "✓ ",
            fontFamily = CyberMonoFamily,
            fontSize = 13.sp,
            color = CyberGreenActive,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = CyberTextSecondary
        )
    }
}

@Composable
private fun ServerConfigDialog(
    currentUrl: String,
    currentDeviceLabel: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var urlInput by remember { mutableStateOf(currentUrl) }
    var labelInput by remember { mutableStateOf(currentDeviceLabel) }
    var urlError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurfaceElevated,
        titleContentColor = CyberTextPrimary,
        textContentColor = CyberTextSecondary,
        title = {
            Text(
                text = "সিগন্যালিং সার্ভার সেটিংস",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "নিরাপদ WebSocket URL (wss://...) অথবা লোকাল টেস্টিংয়ের জন্য ws://... লিখুন:",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = {
                        urlInput = it
                        urlError = null
                    },
                    label = { Text("WebSocket URL") },
                    singleLine = true,
                    isError = urlError != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_server_url"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberBluePrimary,
                        unfocusedBorderColor = CyberBorderGlow,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )
                if (urlError != null) {
                    Text(
                        text = urlError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                OutlinedTextField(
                    value = labelInput,
                    onValueChange = { labelInput = it },
                    label = { Text("ডিভাইসের নাম") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_device_label"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberBluePrimary,
                        unfocusedBorderColor = CyberBorderGlow,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    )
                )
                OutlinedButton(
                    onClick = { urlInput = "ws://10.0.2.2:8443" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("এমুলেটর লোকাল সার্ভার (10.0.2.2:8443)")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = urlInput.trim()
                    if (!trimmed.startsWith("wss://") && !trimmed.startsWith("ws://")) {
                        urlError = "URL অবশ্যই wss:// বা ws:// দিয়ে শুরু হতে হবে"
                    } else {
                        onSave(trimmed, labelInput)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberBluePrimary, contentColor = CyberBlack),
                modifier = Modifier.testTag("btn_save_server")
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = CyberTextSecondary)
            }
        }
    )
}

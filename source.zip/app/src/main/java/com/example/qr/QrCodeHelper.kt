package com.example.qr

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.ServerConfigStore
import com.example.ui.theme.CyberBluePrimary
import com.example.ui.theme.CyberMonoFamily
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject
import java.util.concurrent.Executors

data class ParsedQrPairing(
    val code: String,
    val serverUrl: String?
)

object QrCodeHelper {

    fun buildPairingPayload(code: String, serverUrl: String): String {
        return JSONObject().apply {
            put("app", "DRC")
            put("v", 1)
            put("code", code)
            put("server", serverUrl)
        }.toString()
    }

    fun parsePairingPayload(raw: String): ParsedQrPairing? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        return try {
            if (trimmed.startsWith("{")) {
                val obj = JSONObject(trimmed)
                val appTag = obj.optString("app")
                if (appTag != "DRC") return null
                val code = ServerConfigStore.normalizeCode(obj.optString("code"))
                if (code.length < 6) return null
                val server = obj.optString("server").takeIf {
                    it.startsWith("wss://") || it.startsWith("ws://")
                }
                ParsedQrPairing(code = code, serverUrl = server)
            } else {
                val normalized = ServerConfigStore.normalizeCode(trimmed)
                if (normalized.length >= 6) ParsedQrPairing(normalized, null) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val fgColor = Color.parseColor("#00E5FF")
        val bgColor = Color.parseColor("#050811")
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) fgColor else bgColor)
            }
        }
        return bitmap
    }
}

@Composable
fun QrCodeScannerView(
    onQrDetected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val previewView = remember { PreviewView(context) }

    DisposableEffect(lifecycleOwner) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        var boundProvider: ProcessCameraProvider? = null
        var delivered = false

        val reader = MultiFormatReader().apply {
            setHints(mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)))
        }

        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()
            boundProvider = provider

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(960, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                if (!delivered) {
                    val decoded = decodeQrFromImage(imageProxy, reader)
                    if (decoded != null) {
                        delivered = true
                        ContextCompat.getMainExecutor(context).execute {
                            onQrDetected(decoded)
                        }
                    }
                }
                imageProxy.close()
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            boundProvider?.unbindAll()
            cameraExecutor.shutdown()
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(1.5.dp, CyberBluePrimary, RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )
        // Cyber targeting reticle overlay
        Canvas(modifier = Modifier.size(190.dp)) {
            val len = 28.dp.toPx()
            val stroke = 3.5.dp.toPx()
            val c = CyberBluePrimary
            // Top-left
            drawLine(c, Offset(0f, 0f), Offset(len, 0f), stroke)
            drawLine(c, Offset(0f, 0f), Offset(0f, len), stroke)
            // Top-right
            drawLine(c, Offset(size.width, 0f), Offset(size.width - len, 0f), stroke)
            drawLine(c, Offset(size.width, 0f), Offset(size.width, len), stroke)
            // Bottom-left
            drawLine(c, Offset(0f, size.height), Offset(len, size.height), stroke)
            drawLine(c, Offset(0f, size.height), Offset(0f, size.height - len), stroke)
            // Bottom-right
            drawLine(c, Offset(size.width, size.height), Offset(size.width - len, size.height), stroke)
            drawLine(c, Offset(size.width, size.height), Offset(size.width, size.height - len), stroke)
        }
        Text(
            text = "QR কোডটি ফ্রেমের ভেতরে রাখুন",
            color = ComposeColor.White,
            fontFamily = CyberMonoFamily,
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 14.dp)
        )
    }
}

private fun decodeQrFromImage(imageProxy: ImageProxy, reader: MultiFormatReader): String? {
    return try {
        val plane = imageProxy.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        val source = PlanarYUVLuminanceSource(
            data,
            imageProxy.width,
            imageProxy.height,
            0,
            0,
            imageProxy.width,
            imageProxy.height,
            false
        )
        val bitmap = BinaryBitmap(HybridBinarizer(source))
        reader.decodeWithState(bitmap).text
    } catch (_: Exception) {
        null
    } finally {
        reader.reset()
    }
}

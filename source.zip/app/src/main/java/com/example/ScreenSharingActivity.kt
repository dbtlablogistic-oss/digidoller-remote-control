package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ServerConfigStore
import com.example.network.SignalingClient
import com.example.network.SignalingEvent
import com.example.qr.QrCodeHelper
import com.example.service.ScreenShareForegroundService
import com.example.ui.components.CyberGridBackground
import com.example.ui.components.CyberHudCard
import com.example.ui.components.StatusPulseBadge
import com.example.ui.components.TerminalLogBox
import com.example.ui.theme.CyberAmberWarn
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBlueCobalt
import com.example.ui.theme.CyberBluePrimary
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberGreenActive
import com.example.ui.theme.CyberMonoFamily
import com.example.ui.theme.CyberRedDanger
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.DigidollerTheme
import com.example.webrtc.ConnectionPhase
import com.example.webrtc.RemoteAssistEvent
import com.example.webrtc.WebRtcCallbacks
import com.example.webrtc.WebRtcManager
import kotlinx.coroutines.delay
import org.webrtc.PeerConnection

class ScreenSharingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DigidollerTheme {
                ScreenSharingScreen(onNavigateBack = { finish() })
            }
        }
    }
}

@Composable
fun ScreenSharingScreen(onNavigateBack: () -> Unit) {
    val context = LocalContext.current

    val savedServerUrl by ServerConfigStore.signalingUrlFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.DEFAULT_SIGNALING_URL)
    val deviceName by ServerConfigStore.deviceLabelFlow(context)
        .collectAsStateWithLifecycle(initialValue = ServerConfigStore.defaultDeviceName())

    var oneTimeCode by remember { mutableStateOf(ServerConfigStore.generateOneTimeCode()) }
    var codeSecondsRemaining by remember { mutableIntStateOf(300) }
    var pendingRequest by remember { mutableStateOf<SignalingEvent.IncomingPairRequest?>(null) }
    var pendingOfferSdp by remember { mutableStateOf<String?>(null) }
    var isSharingActive by remember { mutableStateOf(false) }
    var statusNotice by remember { mutableStateOf<String?>(null) }
    var lastAssistPointer by remember { mutableStateOf<RemoteAssistEvent?>(null) }

    val signalingClient = remember { SignalingClient() }
    val phase by signalingClient.phase.collectAsStateWithLifecycle()
    val logs by signalingClient.logs.collectAsStateWithLifecycle()
    val serviceActive by ScreenShareForegroundService.isForegroundActive.collectAsStateWithLifecycle()

    val qrBitmap = remember(oneTimeCode, savedServerUrl) {
        val payload = QrCodeHelper.buildPairingPayload(oneTimeCode, savedServerUrl)
        QrCodeHelper.generateQrBitmap(payload, 512)
    }

    val webRtcHolder = remember { arrayOfNulls<WebRtcManager>(1) }
    val webRtcManager = remember {
        WebRtcManager(
            context = context,
            callbacks = object : WebRtcCallbacks {
                override fun onLocalOfferCreated(sdp: String) {
                    signalingClient.sendOffer(sdp)
                }

                override fun onLocalAnswerCreated(sdp: String) {
                    signalingClient.sendAnswer(sdp)
                }

                override fun onIceCandidateGenerated(
                    sdpMid: String,
                    sdpMLineIndex: Int,
                    candidate: String
                ) {
                    signalingClient.sendIceCandidate(sdpMid, sdpMLineIndex, candidate)
                }

                override fun onIceConnectionChanged(state: PeerConnection.IceConnectionState) {
                    signalingClient.appendLog("WebRTC ICE অবস্থা: $state")
                    when (state) {
                        PeerConnection.IceConnectionState.CONNECTED,
                        PeerConnection.IceConnectionState.COMPLETED -> {
                            signalingClient.updatePhase(ConnectionPhase.CONNECTED)
                            statusNotice = "স্ক্রিন শেয়ারিং সক্রিয় — অনুমোদিত ডিভাইস সংযুক্ত।"
                        }

                        PeerConnection.IceConnectionState.DISCONNECTED,
                        PeerConnection.IceConnectionState.FAILED,
                        PeerConnection.IceConnectionState.CLOSED -> {
                            if (isSharingActive) {
                                statusNotice = "সংযোগ বিচ্ছিন্ন হয়েছে।"
                            }
                        }

                        else -> Unit
                    }
                }

                override fun onAssistEventReceived(event: RemoteAssistEvent) {
                    when (event.type) {
                        "POINTER" -> lastAssistPointer = event
                        "CLEAR_POINTER" -> lastAssistPointer = null
                        "END_SESSION" -> {
                            statusNotice = "Mobile A সেশন বন্ধ করেছে।"
                        }
                    }
                }

                override fun onMediaProjectionStoppedBySystem() {
                    isSharingActive = false
                    lastAssistPointer = null
                    ScreenShareForegroundService.stop(context)
                    signalingClient.disconnect(sendSignal = true)
                    webRtcHolder[0]?.releaseSession()
                    statusNotice = "সিস্টেম থেকে স্ক্রিন শেয়ারিং বন্ধ করা হয়েছে।"
                }

                override fun onError(message: String) {
                    signalingClient.appendLog(message)
                    statusNotice = message
                }
            }
        ).also { webRtcHolder[0] = it }
    }

    fun stopSharingSession(reason: String = "ব্যবহারকারী স্ক্রিন শেয়ারিং বন্ধ করেছেন।") {
        isSharingActive = false
        pendingOfferSdp = null
        lastAssistPointer = null
        ScreenShareForegroundService.stop(context)
        webRtcManager.releaseSession()
        signalingClient.disconnect(sendSignal = true)
        statusNotice = reason
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data: Intent? = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            isSharingActive = true
            signalingClient.appendLog("MediaProjection অনুমতি গৃহীত — স্ক্রিন ক্যাপচার শুরু")
            webRtcManager.createPeerConnection(isController = false)
            webRtcManager.startScreenCaptureAndAttachTrack(data)
            pendingOfferSdp?.let { sdp ->
                webRtcManager.onRemoteOfferReceived(sdp)
                pendingOfferSdp = null
            }
        } else {
            signalingClient.appendLog("MediaProjection অনুমতি বাতিল হয়েছে")
            pendingRequest?.let { req ->
                signalingClient.sendPairDecision(
                    req.controllerId,
                    approved = false,
                    reason = "ব্যবহারকারী Android স্ক্রিন শেয়ার অনুমতি দেননি"
                )
            }
            ScreenShareForegroundService.stop(context)
            isSharingActive = false
            statusNotice = "স্ক্রিন ক্যাপচারের অনুমতি দেওয়া হয়নি।"
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed with MediaProjection intent after ForegroundService starts
        ScreenShareForegroundService.start(context)
        val mpm = context.getSystemService(MediaProjectionManager::class.java)
        mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    fun launchAuthorizedScreenCapture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!notifGranted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        ScreenShareForegroundService.start(context)
        val mpm = context.getSystemService(MediaProjectionManager::class.java)
        mediaProjectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    // Countdown timer for One-Time Code
    LaunchedEffect(oneTimeCode) {
        codeSecondsRemaining = 300
        while (codeSecondsRemaining > 0) {
            delay(1000L)
            codeSecondsRemaining -= 1
        }
    }

    // Connect to Signaling Server when screen opens or code regenerates
    LaunchedEffect(oneTimeCode, savedServerUrl) {
        signalingClient.connectAsHost(savedServerUrl, oneTimeCode, deviceName)
    }

    // Observe Signaling Events
    LaunchedEffect(signalingClient) {
        signalingClient.events.collect { event ->
            when (event) {
                is SignalingEvent.IncomingPairRequest -> {
                    // Explicit consent required before EVERY new session
                    pendingRequest = event
                }

                is SignalingEvent.OfferReceived -> {
                    if (isSharingActive) {
                        webRtcManager.onRemoteOfferReceived(event.sdp)
                    } else {
                        pendingOfferSdp = event.sdp
                    }
                }

                is SignalingEvent.IceCandidateReceived -> {
                    webRtcManager.addRemoteIceCandidate(
                        event.sdpMid,
                        event.sdpMLineIndex,
                        event.candidate
                    )
                }

                is SignalingEvent.PeerDisconnected -> {
                    stopSharingSession(event.reason)
                }

                is SignalingEvent.ServerError -> {
                    statusNotice = event.message
                }

                else -> Unit
            }
        }
    }

    // Observe Stop button tapped from Foreground Notification
    LaunchedEffect(Unit) {
        ScreenShareForegroundService.stopRequested.collect {
            stopSharingSession("নোটিফিকেশন বার থেকে স্ক্রিন শেয়ারিং বন্ধ করা হয়েছে।")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            stopSharingSession("স্ক্রিন শেয়ারিং সেশন সমাপ্ত।")
            webRtcManager.releaseAll()
        }
    }

    Scaffold(
        containerColor = CyberBlack,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        CyberGridBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 680.dp)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Top Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    stopSharingSession()
                                    onNavigateBack()
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("btn_back_host")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "পিছনে যান",
                                    tint = CyberBluePrimary
                                )
                            }
                            Column {
                                Text(
                                    text = "MOBILE B // স্ক্রিন শেয়ারিং",
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 11.sp,
                                    color = CyberBlueCobalt,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "নিরাপদ স্ক্রিন হোস্ট",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CyberTextPrimary
                                )
                            }
                        }
                        StatusPulseBadge(
                            label = if (isSharingActive) "শেয়ারিং চালু" else phase.labelBn,
                            isActive = isSharingActive || phase == ConnectionPhase.WAITING_FOR_PEER,
                            isError = phase == ConnectionPhase.ERROR,
                            activeColor = if (isSharingActive) CyberRedDanger else CyberBluePrimary
                        )
                    }

                    // Always-Visible Sharing Indicator Banner (Zero hidden recording!)
                    AnimatedVisibility(visible = isSharingActive || serviceActive) {
                        CyberHudCard(
                            borderColor = CyberRedDanger,
                            containerColor = CyberRedDanger.copy(alpha = 0.16f)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.FiberManualRecord,
                                        contentDescription = "লাইভ শেয়ারিং চিহ্ন",
                                        tint = CyberRedDanger,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "লাইভ স্ক্রিন শেয়ারিং চালু আছে",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = CyberTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "আপনার ফোনের স্ক্রিন অনুমোদিত ডিভাইসে দৃশ্যমান।",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = CyberTextSecondary
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { stopSharingSession() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberRedDanger,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("btn_stop_sharing_banner")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.StopCircle,
                                    contentDescription = "শেয়ারিং বন্ধ করুন"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("এখনই স্ক্রিন শেয়ারিং বন্ধ করুন")
                            }
                        }
                    }

                    // Assist Pointer Feedback from Mobile A
                    if (lastAssistPointer != null) {
                        val pt = lastAssistPointer!!
                        CyberHudCard(borderColor = CyberAmberWarn) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.TouchApp,
                                    contentDescription = "রিমোট সহায়তা নির্দেশক",
                                    tint = CyberAmberWarn
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "সহায়তা পয়েন্টার (${(pt.xNorm * 100).toInt()}%, ${(pt.yNorm * 100).toInt()}%)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberAmberWarn
                                )
                            }
                        }
                    }

                    if (statusNotice != null) {
                        CyberHudCard(borderColor = CyberBluePrimary.copy(alpha = 0.6f)) {
                            Text(
                                text = statusNotice!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextPrimary
                            )
                        }
                    }

                    // One-Time Code & QR Pairing Card
                    CyberHudCard(borderColor = CyberBluePrimary.copy(alpha = 0.55f)) {
                        Text(
                            text = "One-Time Connection Code ও QR কোড",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "এই কোড বা QR কোডটি Mobile A ডিভাইসে ব্যবহার করুন। একবার ব্যবহারের পর স্বয়ংক্রিয়ভাবে বাতিল হবে।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextSecondary
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Code Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF040812))
                                .border(1.2.dp, CyberBluePrimary, RoundedCornerShape(14.dp))
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = oneTimeCode,
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 3.sp,
                                    color = CyberBluePrimary,
                                    modifier = Modifier.testTag("txt_one_time_code")
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                val mins = codeSecondsRemaining / 60
                                val secs = codeSecondsRemaining % 60
                                Text(
                                    text = "মেয়াদ বাকি: %02d:%02d".format(mins, secs),
                                    fontFamily = CyberMonoFamily,
                                    fontSize = 12.sp,
                                    color = if (codeSecondsRemaining < 60) CyberAmberWarn else CyberGreenActive
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // QR Code Display
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = qrBitmap.asImageBitmap(),
                                contentDescription = "পেয়ারিং QR কোড",
                                modifier = Modifier
                                    .size(210.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(1.5.dp, CyberBlueCobalt, RoundedCornerShape(16.dp))
                                    .testTag("img_pairing_qr")
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedButton(
                            onClick = {
                                stopSharingSession("নতুন One-Time কোড তৈরি হয়েছে।")
                                oneTimeCode = ServerConfigStore.generateOneTimeCode()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_regenerate_code")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "নতুন কোড",
                                tint = CyberBluePrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("নতুন কোড ও QR তৈরি করুন", color = CyberBluePrimary)
                        }
                    }

                    // Security Guarantee Card
                    CyberHudCard(borderColor = CyberBorderGlow) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "নিরাপত্তা গ্যারান্টি",
                                tint = CyberGreenActive
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "জিরো-অনুমতি স্ক্রিন শেয়ারিং সুরক্ষা",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "প্রতিটি সংযোগ অনুরোধে আপনার স্পষ্ট অনুমতি (Allow) এবং Android সিস্টেমের MediaProjection অনুমোদন ছাড়া কোনো স্ক্রিন ডেটা পাঠানো হয় না।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextSecondary
                        )
                    }

                    TerminalLogBox(logs = logs)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }

    // Explicit Consent Dialog for Every Incoming Connection Request
    pendingRequest?.let { request ->
        AlertDialog(
            onDismissRequest = {
                signalingClient.sendPairDecision(
                    request.controllerId,
                    approved = false,
                    reason = "ব্যবহারকারী অনুমতি দেননি"
                )
                pendingRequest = null
            },
            containerColor = CyberSurfaceElevated,
            icon = {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = "সংযোগ অনুরোধ সতর্কতা",
                    tint = CyberAmberWarn,
                    modifier = Modifier.size(34.dp)
                )
            },
            title = {
                Text(
                    text = "নতুন স্ক্রিন শেয়ারিং অনুরোধ",
                    style = MaterialTheme.typography.titleLarge,
                    color = CyberTextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "অনুরোধকারী ডিভাইস: ${request.controllerName}",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberBluePrimary
                    )
                    Text(
                        text = "কোড: ${request.code}",
                        fontFamily = CyberMonoFamily,
                        fontSize = 13.sp,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "আপনি অনুমতি দিলে এই ডিভাইসটি আপনার ফোনের লাইভ স্ক্রিন দেখতে পারবে। আপনি কি নিশ্চিত?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberTextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        signalingClient.sendPairDecision(request.controllerId, approved = true)
                        pendingRequest = null
                        launchAuthorizedScreenCapture()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberGreenActive,
                        contentColor = CyberBlack
                    ),
                    modifier = Modifier.testTag("btn_approve_connection")
                ) {
                    Text("অনুমতি দিন")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        signalingClient.sendPairDecision(
                            request.controllerId,
                            approved = false,
                            reason = "হোস্ট সংযোগ প্রত্যাখ্যান করেছেন"
                        )
                        pendingRequest = null
                    },
                    modifier = Modifier.testTag("btn_reject_connection")
                ) {
                    Text("প্রত্যাখ্যান করুন", color = CyberRedDanger)
                }
            }
        )
    }
}

/**
 * Digidoller Remote Control (DRC V1.0) — Secure WebSocket Signaling Server
 * Developer & Owner: Saheb
 *
 * Enforces:
 * 1. Single-use One-Time Connection Codes with 5-minute TTL
 * 2. Mandatory explicit Host approval (PAIR_DECISION) before SDP/ICE relay
 * 3. Optional TLS (wss://) via SSL_CERT_PATH & SSL_KEY_PATH env vars
 * 4. Automatic room teardown & rate-limiting on failed attempts
 */

const fs = require("fs");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");

const PORT = parseInt(process.env.PORT || "8443", 10);
const CODE_TTL_MS = 5 * 60 * 1000;
const MAX_PAIR_ATTEMPTS_PER_MIN = 12;

// code -> { hostWs, hostName, controllerWs, controllerId, authorized, expiresAt }
const rooms = new Map();
const ipRateLimits = new Map();

function createServer() {
  const certPath = process.env.SSL_CERT_PATH;
  const keyPath = process.env.SSL_KEY_PATH;

  if (certPath && keyPath && fs.existsSync(certPath) && fs.existsSync(keyPath)) {
    return {
      isTls: true,
      server: https.createServer({
        cert: fs.readFileSync(certPath),
        key: fs.readFileSync(keyPath),
      }),
    };
  }
  return {
    isTls: false,
    server: http.createServer((req, res) => {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ app: "DRC Signaling V1.0", status: "ok" }));
    }),
  };
}

const { isTls, server } = createServer();
const wss = new WebSocketServer({ server, maxPayload: 128 * 1024 });

function sendJson(ws, payload) {
  if (ws && ws.readyState === ws.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function isRateLimited(ip) {
  const now = Date.now();
  const entry = ipRateLimits.get(ip) || { count: 0, resetAt: now + 60_000 };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + 60_000;
  }
  entry.count += 1;
  ipRateLimits.set(ip, entry);
  return entry.count > MAX_PAIR_ATTEMPTS_PER_MIN;
}

function cleanupRoom(code, reason) {
  const room = rooms.get(code);
  if (!room) return;
  sendJson(room.hostWs, { type: "PEER_DISCONNECTED", reason });
  sendJson(room.controllerWs, { type: "PEER_DISCONNECTED", reason });
  rooms.delete(code);
}

// Periodically expire unused pairing codes
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms.entries()) {
    if (!room.authorized && now > room.expiresAt) {
      sendJson(room.hostWs, {
        type: "ERROR",
        message: "One-Time কোডের মেয়াদ শেষ হয়েছে।",
      });
      rooms.delete(code);
    }
  }
}, 15_000);

wss.on("connection", (ws, req) => {
  const clientIp = req.socket.remoteAddress || "unknown";
  ws.isAlive = true;
  ws.boundCode = null;
  ws.role = null;

  ws.on("pong", () => {
    ws.isAlive = true;
  });

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString("utf8"));
    } catch {
      sendJson(ws, { type: "ERROR", message: "অবৈধ JSON ফরম্যাট।" });
      return;
    }

    const code = typeof msg.code === "string" ? msg.code.trim().toUpperCase() : "";

    switch (msg.type) {
      case "REGISTER_HOST": {
        if (code.length < 6) {
          sendJson(ws, { type: "ERROR", message: "সঠিক পেয়ারিং কোড দিন।" });
          return;
        }
        if (rooms.has(code)) {
          cleanupRoom(code, "নতুন কোড তৈরি হয়েছে।");
        }
        ws.boundCode = code;
        ws.role = "HOST";
        rooms.set(code, {
          hostWs: ws,
          hostName: String(msg.deviceName || "Mobile B").slice(0, 32),
          controllerWs: null,
          controllerId: null,
          authorized: false,
          expiresAt: Date.now() + CODE_TTL_MS,
        });
        sendJson(ws, {
          type: "HOST_REGISTERED",
          code,
          expiresInSec: Math.floor(CODE_TTL_MS / 1000),
        });
        break;
      }

      case "PAIR_REQUEST": {
        if (isRateLimited(clientIp)) {
          sendJson(ws, {
            type: "ERROR",
            message: "অতিরিক্ত চেষ্টা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।",
          });
          return;
        }
        const room = rooms.get(code);
        if (!room || Date.now() > room.expiresAt) {
          sendJson(ws, {
            type: "ERROR",
            message: "কোড পাওয়া যায়নি বা মেয়াদ শেষ হয়েছে।",
          });
          return;
        }
        if (room.controllerWs && room.authorized) {
          sendJson(ws, {
            type: "ERROR",
            message: "এই One-Time কোড ইতিমধ্যে ব্যবহৃত হয়েছে।",
          });
          return;
        }
        const controllerId = "CTRL-" + crypto.randomBytes(4).toString("hex").toUpperCase();
        ws.boundCode = code;
        ws.role = "CONTROLLER";
        room.controllerWs = ws;
        room.controllerId = controllerId;

        sendJson(room.hostWs, {
          type: "PAIR_REQUEST",
          code,
          controllerId,
          deviceName: String(msg.deviceName || "Mobile A").slice(0, 32),
        });
        break;
      }

      case "PAIR_DECISION": {
        const room = rooms.get(code);
        if (!room || room.hostWs !== ws) return;
        if (msg.controllerId !== room.controllerId) return;

        if (msg.approved === true) {
          room.authorized = true;
          const sessionToken = crypto.randomBytes(24).toString("hex");
          sendJson(room.controllerWs, {
            type: "PAIR_APPROVED",
            hostName: room.hostName,
            sessionToken,
          });
        } else {
          sendJson(room.controllerWs, {
            type: "PAIR_REJECTED",
            reason: String(msg.reason || "হোস্ট অনুমতি দেননি।"),
          });
          room.controllerWs = null;
          room.controllerId = null;
          room.authorized = false;
        }
        break;
      }

      case "OFFER":
      case "ANSWER":
      case "ICE_CANDIDATE": {
        const room = rooms.get(code);
        // Zero signaling relay before explicit Host authorization
        if (!room || !room.authorized) {
          sendJson(ws, {
            type: "ERROR",
            message: "অনুমোদিত সেশন ছাড়া WebRTC সিগন্যালিং অনুমোদিত নয়।",
          });
          return;
        }
        const target = ws === room.hostWs ? room.controllerWs : room.hostWs;
        sendJson(target, msg);
        break;
      }

      case "DISCONNECT": {
        if (code) {
          cleanupRoom(code, "সেশন বন্ধ করা হয়েছে।");
        }
        break;
      }
    }
  });

  ws.on("close", () => {
    if (ws.boundCode) {
      cleanupRoom(ws.boundCode, "ডিভাইস সংযোগ বিচ্ছিন্ন হয়েছে।");
    }
  });
});

// Keepalive ping
setInterval(() => {
  wss.clients.forEach((client) => {
    if (!client.isAlive) return client.terminate();
    client.isAlive = false;
    client.ping();
  });
}, 25_000);

server.listen(PORT, () => {
  console.log(`DRC Secure Signaling Server running on ${isTls ? "wss" : "ws"}://0.0.0.0:${PORT}`);
});
